package CardGamepack;

import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Display4_EndingDisplay {
	public static void showDisplay4(String Winner) {
		
		Music.StopMusic();
		
		Music.Ending(Winner);
        JFrame frame = new JFrame("Game Ending");

        frame.getContentPane().setPreferredSize(new Dimension(1200, 600));

        JPanel panel = new JPanel();
        panel.setLayout(null);

        String imagePath = "res/Ending/" + Winner + "_Win.png";
        ImageIcon endingImage = new ImageIcon(imagePath);
        JLabel endingLabel = new JLabel(endingImage);
        endingLabel.setBounds(0, 0, 1200, 600);
        panel.add(endingLabel);

        frame.add(panel);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
	}
}
