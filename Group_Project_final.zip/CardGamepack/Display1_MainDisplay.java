package CardGamepack;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import GUI.InGame;
import GUI.WarService;

public class Display1_MainDisplay {
	
	public static void ShowDisplay1(MainService mainservice) {
        JFrame frame = new JFrame("WarGame");

        frame.getContentPane().setPreferredSize(new Dimension(1200, 600));

        JPanel panel = new JPanel();
        panel.setLayout(null);


        ImageIcon Mainbg = new ImageIcon("res/MainBackground.png");
        JLabel Mainbag = new JLabel(Mainbg);
        Mainbag.setBounds(0, 0, 1200, 600);
        panel.add(Mainbag);

        ImageIcon StartGame = new ImageIcon("res/Start_game.png");
        JLabel RaceStart = new JLabel(StartGame);
        RaceStart.setBounds(834, 367, 268, 50);panel.add(RaceStart);
        
        ImageIcon Howto = new ImageIcon("res/How_to.png");
        JLabel howgame = new JLabel(Howto);
        howgame.setBounds(834, 452, 268, 50);panel.add(howgame);
        
        
        RaceStart.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                Display2_PreparationDisplay.showDisplay2(mainservice);
                
                //Display4_EndingDisplay.showDisplay4("Computer");
            }
        });
        
        howgame.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Game Tutorial");
                String message = "How to play Game\n\n"
                        + "1. Each player gets half of the deck.\n"
                        + "2. Each round, both players flip their top card.\n"
                        + "3. The player with the higher card takes both cards and adds them to the bottom of their deck.\n"
                        + "4. If the cards are equal in value, It's 'War'!:\n"
                        + "   - Each player places three cards face down and one card face up.\n"
                        + "   - The higher face-up card wins all the cards on the table.\n"
                        + "   - If the face-up cards tie again during a war, another war starts and the process in Step 4 repeats until the tie is broken!\n"
                        + "5. Keep playing until one player has all the cards.\n\n"
                        + "Card Rankings: A > K > Q > J > 10 > 9 > 8 > 7 > 6 > 5 > 4 > 3 > 2";

                JOptionPane.showMessageDialog(
                        frame,
                        message,
                        "How to Play",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }
        });
        
        
        panel.setComponentZOrder(Mainbag, panel.getComponentCount() - 1);

        frame.add(panel);
        frame.pack();  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
