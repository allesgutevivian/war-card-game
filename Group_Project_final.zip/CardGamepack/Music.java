package CardGamepack;

import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;

public class Music {
    
	private static Clip clip;
	public static void MainMusic() {
        new Thread(() -> {
            try {
                File audioFile = new File("res/music/MainBackgrounMusic.wav");
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
                clip = AudioSystem.getClip();
                clip.open(audioStream);
                clip.loop(Clip.LOOP_CONTINUOUSLY);
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    public static void StopMusic() {
        if (clip != null && clip.isRunning()) {
            clip.stop();     // 재생 멈춤
            clip.close();    // 리소스 해제
        }
    }
    
    
    public static void CardOpenMusic() {
        new Thread(() -> {
            try {
                File audioFile = new File("res/music/cardsound.wav");
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);

                Clip clip = AudioSystem.getClip();
                clip.open(audioStream);
                FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                gainControl.setValue(-10.0f); // -10dB: 약간 줄인 상태 (0이 기본값)
                clip.start();

                // 이벤트 리스너 등록
                clip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP) {
                        clip.close(); // 재생 끝나면 자동으로 클립 닫기
                    }
                });

            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    
    public static void Ending(String Winner) {
    	
    	String path;
    	if (Winner.equals("User")) {
    		path = "res/music/victorysound.wav";
    	} else {
    		path = "res/music/gameoversound.wav";
    	}
    	
        new Thread(() -> {
            try {
                File audioFile = new File(path);
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);

                Clip clip = AudioSystem.getClip();
                clip.open(audioStream);
                FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                gainControl.setValue(-10.0f); // -10dB: 약간 줄인 상태 (0이 기본값)
                clip.start();

                // 이벤트 리스너 등록
                clip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP) {
                        clip.close(); // 재생 끝나면 자동으로 클립 닫기
                    }
                });

            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                e.printStackTrace();
            }
        }).start();
    }

}
