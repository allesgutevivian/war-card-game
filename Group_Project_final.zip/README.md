the package name is "CardGamepack"

the resources folder "res" must be located with "src" foler, **not in "src"**.

To operate program, start the "GameStart.java".

To terminate game, press "Enter" in display 3.