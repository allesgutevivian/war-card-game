package CardGamepack;

public class Card {
	String suit;
	String value;

	public Card(String suit, String value) {
		this.suit = suit;
		this.value = value;
	}

	public String toString() {
		return "Rank=" + this.value + ", Suit=" + this.suit + ".png";
	}
	
	public int getNumber() {
		if(this.value.equals("A")) return 14;
		else if(this.value.equals("K")) return 13;
		else if(this.value.equals("Q")) return 12;
		else if(this.value.equals("J")) return 11;
		else return Integer.parseInt(this.value);
	}
}
