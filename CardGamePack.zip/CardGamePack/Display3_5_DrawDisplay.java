package CardGamepack;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Display3_5_DrawDisplay {
	
	static int uindex =1; static int cindex=1;
	
	public static void showDisplay3_5(MainService mainservice) {
		
		
		System.out.println("Display3_5");
		List<Card> userCardForWar = mainservice.Display3_5_for_user();
		List<Card> computerCardForWar = mainservice.Display3_5_for_computer();
		
		String upath = userCardForWar.get(0).toString();
		String cpath = computerCardForWar.get(0).toString();
		System.out.println("User: " + upath + "\nCompuer: " + cpath);
		
		
		
		for (int i = 1; i <userCardForWar.size(); i++ ) {
			for (int j = 1; j <computerCardForWar.size(); j++) {
				if (userCardForWar.get(i).getNumber() != computerCardForWar.get(j).getNumber()) {
					uindex = i;
					cindex = j;
				}
			}
		}
		
		
		
		
		
		JFrame frame = new JFrame("WarGame");

        frame.getContentPane().setPreferredSize(new Dimension(1200, 600));

        JPanel panel = new JPanel();
        panel.setLayout(null);

        // 배경 이미지를 가장 먼저 추가해야 다른 컴포넌트가 위에 나타남
        ImageIcon Mainbg = new ImageIcon("res/Gamebg.png");
        JLabel Mainbag = new JLabel(Mainbg);
        Mainbag.setBounds(0, 0, 1200, 600);
        panel.add(Mainbag);
        
        
        ImageIcon Cardb1 = new ImageIcon("res/CardBack.png");
        JLabel CardbImg1 = new JLabel(Cardb1);
        CardbImg1.setBounds(30, 95, 300, 409);
        panel.add(CardbImg1);
        
        
        ImageIcon Opencd1 = new ImageIcon("res/Cards/" + upath);
        JLabel OpenCard1 = new JLabel(Opencd1);
        OpenCard1.setBounds(110, 120, 300, 409);
        panel.add(OpenCard1);

        
        ImageIcon Cardb2 = new ImageIcon("res/CardBack.png");
        JLabel CardbImg2 = new JLabel(Cardb2);
        CardbImg2.setBounds(870, 95, 300, 409);panel.add(CardbImg2);
        
        ImageIcon Opencd2= new ImageIcon("res/Cards/" + cpath); // Rank=7, Suit=Spades️.png                          
        JLabel OpenCard2 = new JLabel(Opencd2);
        OpenCard2.setBounds(790, 120, 300, 409);
        panel.add(OpenCard2);
        
        ImageIcon nround= new ImageIcon("res/GoWar.png");                         
        JLabel Nround = new JLabel(nround);
        Nround.setBounds(466, 529, 268, 50);
        panel.add(Nround);
        
        
        String userStack = String.valueOf(mainservice.getUser().size());
        ImageIcon ustack= new ImageIcon("res/Stack/User_ " + userStack + ".png"); // Rank=7, Suit=Spades️.png                          
        JLabel Ustack = new JLabel(ustack);
        Ustack.setBounds(72, 34, ustack.getIconWidth(), ustack.getIconHeight());
        panel.add(Ustack);
        
        
        String computerStack = String.valueOf(mainservice.getComputer().size());
        ImageIcon cstack= new ImageIcon("res/Stack/Computer_ " + computerStack + ".png"); // Rank=7, Suit=Spades️.png                          
        JLabel Cstack = new JLabel(cstack);
        Cstack.setBounds(876, 30, cstack.getIconWidth(), cstack.getIconHeight());
        panel.add(Cstack);
       
        Nround.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
            	frame.dispose();
                
            	Display3_7_WarDisplay.showDisplay3_7(mainservice, userCardForWar, computerCardForWar, uindex, cindex);
                           
            }
        });

        
        
     
        
        
        
        panel.setComponentZOrder(Mainbag, panel.getComponentCount() - 1);

        panel.setComponentZOrder(CardbImg1, panel.getComponentCount() - 2);
        panel.setComponentZOrder(CardbImg2, panel.getComponentCount() - 3);

        frame.add(panel);
        frame.pack();  // preferredSize 적용
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        
        
        
        
	}
}
