package CardGamepack;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import GUI.ShowCard;
import GUI.WarService;

public class Display3_OpenCardDisplay {
	public static void showDisplay3(MainService mainservice) {
		
		System.out.println("Display3");
		String[] content = mainservice.Display3();
		
		
		String upath = content[0];
		String cpath = content[1];
		String Winner = content[2];
		String userStack = content[3];
		String computerStack = content[4];
		System.out.println("User: " + upath + "\nCompuer: " + cpath);
		System.out.println(Winner);
		
		
		
		
		JFrame frame = new JFrame("WarGame");

        frame.getContentPane().setPreferredSize(new Dimension(1200, 600));

        JPanel panel = new JPanel();
        panel.setLayout(null);

        // 배경 이미지를 가장 먼저 추가해야 다른 컴포넌트가 위에 나타남
        ImageIcon Mainbg = new ImageIcon("res/Gamebg.png");
        JLabel Mainbag = new JLabel(Mainbg);
        Mainbag.setBounds(0, 0, 1200, 600);
        panel.add(Mainbag);
        
        
        ImageIcon Cardb1 = new ImageIcon("res/CardBack.png");
        JLabel CardbImg1 = new JLabel(Cardb1);
        CardbImg1.setBounds(30, 95, 300, 409);
        panel.add(CardbImg1);
        
        
        ImageIcon Opencd1 = new ImageIcon("res/Cards/" + upath);
        JLabel OpenCard1 = new JLabel(Opencd1);
        OpenCard1.setBounds(110, 120, 300, 409);
        panel.add(OpenCard1);

        
        ImageIcon Cardb2 = new ImageIcon("res/CardBack.png");
        JLabel CardbImg2 = new JLabel(Cardb2);
        CardbImg2.setBounds(870, 95, 300, 409);panel.add(CardbImg2);
        
        ImageIcon Opencd2= new ImageIcon("res/Cards/" + cpath); // Rank=7, Suit=Spades️.png                          
        JLabel OpenCard2 = new JLabel(Opencd2);
        OpenCard2.setBounds(790, 120, 300, 409);
        panel.add(OpenCard2);
        
        ImageIcon ustack= new ImageIcon("res/Stack/User_ " + userStack + ".png"); // Rank=7, Suit=Spades️.png                          
        JLabel Ustack = new JLabel(ustack);
        Ustack.setBounds(72, 34, ustack.getIconWidth(), ustack.getIconHeight());
        panel.add(Ustack);
        
        ImageIcon cstack= new ImageIcon("res/Stack/Computer_ " + computerStack + ".png"); // Rank=7, Suit=Spades️.png                          
        JLabel Cstack = new JLabel(cstack);
        Cstack.setBounds(876, 30, cstack.getIconWidth(), cstack.getIconHeight());
        panel.add(Cstack);
        
        
        ImageIcon wround= new ImageIcon("res/Round_" + Winner + ".png");                        
        JLabel Wround = new JLabel(wround);
        Wround.setBounds(488, 41, 255, 453);
        panel.add(Wround);
        
        ImageIcon nround= new ImageIcon("res/GoNextRound.png");                         
        JLabel Nround = new JLabel(nround);
        Nround.setBounds(466, 529, 268, 50);
        panel.add(Nround);
        
        
        Nround.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                if (mainservice.GamePossible()) {
	                if (mainservice.IsWar()) {
	                	if (mainservice.WarPossible()) {
	                		Display3_5_DrawDisplay.showDisplay3_5(mainservice);
	                	} else {
	                		Display4_EndingDisplay.showDisplay4(mainservice.goEnding());
	                	}
	                	
	                } else {
	                	Display3_OpenCardDisplay.showDisplay3(mainservice); 
	                	
	                }
                } else {
                	Display4_EndingDisplay.showDisplay4(mainservice.goEnding());
                }
                           
            }
        });
       
        
        
        
     
        
        
        
        panel.setComponentZOrder(Mainbag, panel.getComponentCount() - 1);

        panel.setComponentZOrder(CardbImg1, panel.getComponentCount() - 2);
        panel.setComponentZOrder(CardbImg2, panel.getComponentCount() - 3);

        frame.add(panel);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        
        
        
        
	}
}
