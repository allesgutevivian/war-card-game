package CardGamepack;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import GUI.ShowCard;
import GUI.WarService;

public class Display2_PreparationDisplay {
	public static void showDisplay2(MainService mainservice) {
		JFrame frame = new JFrame("WarGame");

        frame.getContentPane().setPreferredSize(new Dimension(1200, 600));

        JPanel panel = new JPanel();
        panel.setLayout(null);
        
        // 배경 이미지를 가장 먼저 추가해야 다른 컴포넌트가 위에 나타남
        ImageIcon Mainbg = new ImageIcon("res/Gamebg.png");
        JLabel Mainbag = new JLabel(Mainbg);
        Mainbag.setBounds(0, 0, 1200, 600);
        panel.add(Mainbag);
        
        
        ImageIcon Cardb1 = new ImageIcon("res/CardBack.png");
        JLabel CardbImg1 = new JLabel(Cardb1);
        CardbImg1.setBounds(30, 95, 300, 409);
        panel.add(CardbImg1);

        
        ImageIcon Cardb2 = new ImageIcon("res/CardBack.png");
        JLabel CardbImg2 = new JLabel(Cardb2);
        CardbImg2.setBounds(870, 95, 300, 409);panel.add(CardbImg2);
        
        ImageIcon open = new ImageIcon("res/Open.png");
        JLabel OpenGame = new JLabel(open);
        OpenGame.setBounds(466, 529, 268, 50);panel.add(OpenGame);
        
        OpenGame.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                
                if (mainservice.IsWar()) {
                	Display3_5_DrawDisplay.showDisplay3_5(mainservice);
                	
                } else {
                	Display3_OpenCardDisplay.showDisplay3(mainservice); 
                	
                }
                           
            }
        });

        
        panel.setComponentZOrder(Mainbag, panel.getComponentCount() - 1);

        frame.add(panel);
        frame.pack();  // preferredSize 적용
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
	}
}
