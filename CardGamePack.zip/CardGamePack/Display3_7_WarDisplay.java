package CardGamepack;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Display3_7_WarDisplay {
	
	public static void showDisplay3_7(MainService mainservice, List<Card> userCardListForWar, List<Card> computerCardListForWar, int userindex, int computerindex) {
		System.out.println("Display3_7");
		String[] content = mainservice.Display3_7(userCardListForWar, computerCardListForWar, userindex, computerindex);
		
		
		String upath = userCardListForWar.get(0).toString();
		String unpath = userCardListForWar.get(userindex).toString();
		
		String cpath = computerCardListForWar.get(0).toString();
		String cnpath = computerCardListForWar.get(computerindex).toString();
		
		String Winner = content[0];
		String userStack = content[1];
		String computerStack = content[2];
		System.out.println("User: " + upath + "\nCompuer: " + cpath);
		System.out.println(Winner);
		
		
		
		
		JFrame frame = new JFrame("WarGame");

        frame.getContentPane().setPreferredSize(new Dimension(1200, 600));

        JPanel panel = new JPanel();
        panel.setLayout(null);

        // 배경 이미지를 가장 먼저 추가해야 다른 컴포넌트가 위에 나타남
        ImageIcon Mainbg = new ImageIcon("res/Gamebg.png");
        JLabel Mainbag = new JLabel(Mainbg);
        Mainbag.setBounds(0, 0, 1200, 600);
        panel.add(Mainbag);
        
        
        ImageIcon Cardb1 = new ImageIcon("res/CardBack.png");
        JLabel CardbImg1 = new JLabel(Cardb1);
        CardbImg1.setBounds(30, 95, 300, 409);
        panel.add(CardbImg1);
        
        
        ImageIcon Opencd1 = new ImageIcon("res/Cards/" + upath);
        JLabel OpenCard1 = new JLabel(Opencd1);
        OpenCard1.setBounds(110, 120, 300, 409);
        panel.add(OpenCard1);
        
        ImageIcon Opencd3 = new ImageIcon("res/Cards/" + unpath);
        JLabel OpenCard3 = new JLabel(Opencd3);
        OpenCard3.setBounds(180, 120, 300, 409);
        panel.add(OpenCard3);

        
        ImageIcon Cardb2 = new ImageIcon("res/CardBack.png");
        JLabel CardbImg2 = new JLabel(Cardb2);
        CardbImg2.setBounds(870, 95, 300, 409);panel.add(CardbImg2);
        
        ImageIcon Opencd2= new ImageIcon("res/Cards/" + cpath); // Rank=7, Suit=Spades️.png                          
        JLabel OpenCard2 = new JLabel(Opencd2);
        OpenCard2.setBounds(790, 120, 300, 409);
        panel.add(OpenCard2);
        ImageIcon Opencd4= new ImageIcon("res/Cards/" + cnpath); // Rank=7, Suit=Spades️.png                          
        JLabel OpenCard4 = new JLabel(Opencd4);
        OpenCard4.setBounds(730, 120, 300, 409);
        panel.add(OpenCard4);
        
        ImageIcon ustack= new ImageIcon("res/Stack/User_ " + userStack + ".png"); // Rank=7, Suit=Spades️.png                          
        JLabel Ustack = new JLabel(ustack);
        Ustack.setBounds(72, 34, ustack.getIconWidth(), ustack.getIconHeight());
        panel.add(Ustack);
        
        ImageIcon cstack= new ImageIcon("res/Stack/Computer_ " + computerStack + ".png"); // Rank=7, Suit=Spades️.png                          
        JLabel Cstack = new JLabel(cstack);
        Cstack.setBounds(876, 30, cstack.getIconWidth(), cstack.getIconHeight());
        panel.add(Cstack);
        
        
        ImageIcon c1= new ImageIcon("res/CardBack_small.png"); // Rank=7, Suit=Spades️.png                          
        JLabel C1 = new JLabel(c1);
        C1.setBounds(377, 128, 164, 120);
        panel.add(C1);
        ImageIcon c2= new ImageIcon("res/CardBack_small.png"); // Rank=7, Suit=Spades️.png                          
        JLabel C2 = new JLabel(c2);
        C2.setBounds(377, 258, 164, 120);
        panel.add(C2);
        ImageIcon c3= new ImageIcon("res/CardBack_small.png"); // Rank=7, Suit=Spades️.png                          
        JLabel C3 = new JLabel(c3);
        C3.setBounds(377, 388, 164, 120);
        panel.add(C3);
        
        ImageIcon c4= new ImageIcon("res/CardBack_small.png"); // Rank=7, Suit=Spades️.png                          
        JLabel C4 = new JLabel(c4);
        C4.setBounds(669, 128, 164, 120);
        panel.add(C4);
        ImageIcon c5= new ImageIcon("res/CardBack_small.png"); // Rank=7, Suit=Spades️.png                          
        JLabel C5 = new JLabel(c5);
        C5.setBounds(669, 258, 164, 120);
        panel.add(C5);
        ImageIcon c6= new ImageIcon("res/CardBack_small.png"); // Rank=7, Suit=Spades️.png                          
        JLabel C6 = new JLabel(c6);
        C6.setBounds(669, 388, 164, 120);
        panel.add(C6);
        
        
        
        
        
        
        
        
        
        
        
        
        
        ImageIcon wround= new ImageIcon("res/War_win_" + Winner + ".png");                        
        JLabel Wround = new JLabel(wround);
        if (Winner.equals("User")) {
        	Wround.setBounds(14, 11, 283, 80); 
        } else {
        	Wround.setBounds(857, 11,283, 80);
        }
        panel.add(Wround);
        
        ImageIcon nround= new ImageIcon("res/GoNextRound.png");                         
        JLabel Nround = new JLabel(nround);
        Nround.setBounds(466, 539, 268, 50);
        panel.add(Nround);
        
        
        Nround.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                if (mainservice.GamePossible()) {
	                if (mainservice.IsWar()) {
	                	if (mainservice.WarPossible()) {
	                		Display3_5_DrawDisplay.showDisplay3_5(mainservice);
	                	} else {
	                		Display4_EndingDisplay.showDisplay4(mainservice.goEnding());
	                	}
	                	
	                } else {
	                	Display3_OpenCardDisplay.showDisplay3(mainservice); 
	                	
	                }
                } else {
                	Display4_EndingDisplay.showDisplay4(mainservice.goEnding());
                }
                           
            }
        });
       
        
        
        
     
        
        
        
        panel.setComponentZOrder(Mainbag, panel.getComponentCount() - 1);

        panel.setComponentZOrder(CardbImg1, panel.getComponentCount() - 2);
        panel.setComponentZOrder(CardbImg2, panel.getComponentCount() - 3);
        panel.setComponentZOrder(OpenCard1, panel.getComponentCount() - 4);
        panel.setComponentZOrder(OpenCard2, panel.getComponentCount() - 5);

        frame.add(panel);
        frame.pack();  // preferredSize 적용
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
	}
	
	
}
