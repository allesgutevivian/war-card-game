package CardGamepack;

import java.util.*;



public class MainService {
	//long Round = 0;
	String[] suits = {"Diamond","Spades","Clubs","Heart"};
	String[] number = {"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
	
	List<Card> deck = new ArrayList<>();
	static List<Card> user = new ArrayList<>();
	static List<Card> computer = new ArrayList<>();
	
	public List<Card> getUser() {
		return user;
	}


	public List<Card> getComputer() {
		return computer;
	}
	
	// Shuffle
	public MainService() {
		for (String suit : suits) {
	        for (String rank : number) {
	            deck.add(new Card(suit,rank));
	        }
	    }
		
		Collections.shuffle(deck);// shuffle the cards 洗牌 섞다
		
		for(int i=0;i< deck.size();i++) {
			if(i%2 == 0) {
				user.add(deck.get(i));
			} else {
				computer.add(deck.get(i));
			}
		}
	}
	
	
	public boolean IsWar() {
		Card userCard = user.get(0);
		Card ComputerCard =computer.get(0);
		
		if (userCard.getNumber() == ComputerCard.getNumber()) {
			return true;
		} else {
			return false;
		}
	}
	
	public String WhoWinner(Card u1, Card c2) {

		if (u1.getNumber() > c2.getNumber()) {
			return "User";
		} else {
			return "Computer";
		}
	}
	
	
	public String[] Display3() {
		String[] upath_cpath_winner_ustack_cstack = new String[5];
		
		Card userCard = user.get(0);
		Card ComputerCard =computer.get(0);
		upath_cpath_winner_ustack_cstack[0] = userCard.toString();
		upath_cpath_winner_ustack_cstack[1] = ComputerCard.toString();
		upath_cpath_winner_ustack_cstack[2] = WhoWinner(userCard, ComputerCard);
		
		
		List<Card> pile = new ArrayList<>();
		pile.add(userCard); pile.add(ComputerCard);
		user.remove(0); computer.remove(0);
		
		if (upath_cpath_winner_ustack_cstack[2].equals("User")) {
			user.addAll(pile);
		} else {
			computer.addAll(pile);
		}
		
		upath_cpath_winner_ustack_cstack[3] = String.valueOf(user.size());
		upath_cpath_winner_ustack_cstack[4] = String.valueOf(computer.size());
		
		Collections.shuffle(user);
		Collections.shuffle(computer);
		return upath_cpath_winner_ustack_cstack;
	}
	
	public List<Card> Display3_5_for_user() {
		List<Card> userCardForWar = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			userCardForWar.add(user.get(i));
		}
		
		return userCardForWar;
	}
	public List<Card> Display3_5_for_computer() {
		List<Card> computerCardForWar = new ArrayList<>();
		
		for (int i = 0; i < 5; i++) {
			computerCardForWar.add(computer.get(i));
		}
		
		return computerCardForWar;
	}
	
	
	public String[] Display3_7(List<Card> userCardListForWar, List<Card> computerCardListForWar, int userindex, int computerindex) {
		
		String[] Winner_uStack_cStack = new String[3];
		
		if (WhoWinner(userCardListForWar.get(userindex), computerCardListForWar.get(computerindex)).equals("User")) {
			Winner_uStack_cStack[0] = "User";
			user.addAll(computerCardListForWar);
			for (int i = 0; i < computerCardListForWar.size(); i++) {
				computer.remove(0);
			}
		} else {
			Winner_uStack_cStack[0] = "Computer";
			computer.addAll(userCardListForWar);
			for (int i = 0; i < userCardListForWar.size(); i++) {
				user.remove(0);
			}
		}
		
		Winner_uStack_cStack[1] = String.valueOf(user.size());
		Winner_uStack_cStack[2] = String.valueOf(computer.size());
		
		return Winner_uStack_cStack;
	}
	
	
	public boolean GamePossible() {
		return !(user.isEmpty() || computer.isEmpty());
	}
	
	public boolean WarPossible() {
		if ((user.size() <5 ) || (computer.size() < 5)) {
			return false;
		} else {
			return true;
		}
	}
	
	
	public String goEnding() {
		if (user.size() > computer.size()) {
			return "User";
		} else {
			return "Computer";
		}
	}
	
	
	
	
	
}
