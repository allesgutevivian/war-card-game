package CardGamepack;

public class Display4_EndingDisplay {
	public static void showDisplay4(String Winner) {
		
	}
}
