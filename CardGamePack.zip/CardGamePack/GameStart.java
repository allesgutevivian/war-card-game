package CardGamepack;

public class GameStart {

	public static void main(String[] args) {
		MainService mainservice = new MainService();
		
		Display1_MainDisplay.ShowDisplay1(mainservice);
		
	}

}
